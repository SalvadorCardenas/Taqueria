DROP DATABASE IF EXISTS `taqueriapro`;

CREATE DATABASE IF NOT EXISTS `taqueriapro` /*!40100 DEFAULT CHARACTER SET utf8mb3 */;
USE `taqueriapro`;

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE IF NOT EXISTS `categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `categoria` (`id_categoria`, `nombre`) VALUES
	(null, 'Tacos'),
	(null, 'Quesadillas'),
	(null, 'Tortas'),
	(null, 'Papas'),
	(null, 'Bebidas');

DROP TABLE IF EXISTS `alimento`;
CREATE TABLE IF NOT EXISTS `alimento` (
  `id_alimento` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `precio` varchar(15) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `imagen` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_alimento`),
  KEY `categoriaFK` (`id_categoria`),
  CONSTRAINT `categoriaFK` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `alimento` (`id_alimento`, `nombre`, `precio`, `id_categoria`, `imagen`) VALUES
	(null, 'tacos de pastor', '12', 1, '/tacos de pastor.jpeg'),
	(null, 'tacos chorizo', '13', 1, '/tacos chorizo.jpeg'),
	(null, 'tacos lengua', '15', 1, '/tacos lengua.jpeg'),
	(null, 'quesadilla sencilla', '18', 2, '/quesadilla sencilla.jpeg'),
	(null, 'quesadilla con pastor', '25', 2, '/quesadilla con pastor.jpeg'),
	(null, 'quesadilla de costilla', '23', 2, '/quesadilla de costilla.jpeg'),
	(null, 'quesadilla con chorizo', '23', 2, '/quesadilla con chorizo.jpeg'),
	(null, 'tortas de pastor', '25', 3, '/tortas de pastor.jpeg'),
	(null, 'torta cubana', '40', 3, '/torta cubana.jpeg'),
	(null, 'torta choriqueso', '30', 3, '/torta choriqueso.jpeg'),
	(null, 'torta carne asada', '25', 3, '/torta carne asada.jpeg'),
	(null, 'torta milanesa', '30', 3, '/torta milanesa.jpeg'),
	(null, 'papa con pastor y queso', '28', 4, '/papa con pastor y queso.jpeg'),
	(null, 'papa con chorizo y queso', '24', 4, '/papa con chorizo y queso.jpeg'),
	(null, 'papa con arrachera y queso', '32', 4, '/papa con arrachera y queso.jpeg'),
	(null, 'Coca Cola 600ml', '19', 5, '/Coca Cola 600ml.jpeg'),
	(null, 'Mundet 600ml', '19', 5, '/Mundet 600ml.jpeg'),
	(null, 'Agua Horchata 1lt', '22', 5, '/Agua Horchata 1lt.jpeg'),
	(null, 'Agua Jamaica 1lt', '22', 5, '/Agua jamaica 1lt.jpeg');

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`id_cliente`) VALUES
	(1),
	(2),
	(3),
	(4),
	(5),
	(6),
	(7),
	(8);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

DROP TABLE IF EXISTS `orden`;
CREATE TABLE IF NOT EXISTS `orden` (
  `id_orden` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `id_alimento` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_orden`),
  KEY `alimentoFK` (`id_alimento`),
  KEY `clienteFK` (`id_cliente`),
  KEY `categoriaOrdenFK` (`id_categoria`),
  CONSTRAINT `alimentoFK` FOREIGN KEY (`id_alimento`) REFERENCES `alimento` (`id_alimento`),
  CONSTRAINT `categoriaOrdenFK` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `clienteFK` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

